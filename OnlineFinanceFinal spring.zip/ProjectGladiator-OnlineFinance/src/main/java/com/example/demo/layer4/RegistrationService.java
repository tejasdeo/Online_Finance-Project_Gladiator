package com.example.demo.layer4;

import org.springframework.stereotype.Service;

import com.example.demo.layer2.Registration;

@Service
public interface RegistrationService {

	public String insertUser(Registration register);
}
