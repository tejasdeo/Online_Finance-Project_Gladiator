package com.example.demo.layer3;

import java.sql.Date;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.Product_details;
import com.example.demo.layer2.Transaction;
import com.example.demo.layer2.UserInformation;
@Repository
public interface TransactionRepo {


	void insertTransaction(Transaction ref);
	Transaction selectTransactionBytxn_id(int txnid);
    List<Transaction> selectTransactionByuser_id(int user_id,int product_id);
    UserInformation selectUserbyId(int user_id);
	Product_details selectProductbyId(int product_id);
    }
