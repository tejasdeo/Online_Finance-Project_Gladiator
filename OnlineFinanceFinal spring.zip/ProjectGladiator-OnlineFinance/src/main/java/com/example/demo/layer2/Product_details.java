package com.example.demo.layer2;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="product_details")
public class Product_details {
    
	@Id
	@GeneratedValue
	@Column(name="product_id")
	private int product_id;
	@Column(name="product_type")
	private String product_type;
	@Column(name="product_name")
	private String product_name;
	@Column(name="cost")
	private double cost;
	@Column(name="imageurl")
	private String imageurl;
	public String getImageurl() {
		return imageurl;
	}
	public void setImgurl(String imageurl) {
		this.imageurl = imageurl;
	}
	public int getProduct_id() {
		return product_id;
	}
	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}
	public String getProduct_type() {
		return product_type;
	}
	public void setProduct_type(String product_type) {
		this.product_type = product_type;
	}
	public String getProduct_name() {
		return product_name;
	}
	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}
	public double getCost() {
		return cost;
	}
	public void setCost(double cost) {
		this.cost = cost;
	}

}
