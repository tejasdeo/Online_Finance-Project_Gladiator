package com.example.demo.layer4;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.layer2.Product_details;
import com.example.demo.layer2.Transaction;

@Service
public interface TransactionService {

	 void insertTransactionService(Transaction txn,int user_id,int product_id);
	 List<Transaction> selectTransactionbyUseridService(int user_id,int product_id);
	 Product_details selectProductbyIdService(int product_id);	
}
