package com.example.demo.layer2;


public class CardNotFoundException extends Exception {
	public CardNotFoundException(String str) {
		super(str);
	}
	public String getMessage()
	{
		return "Card not found";
	}
}