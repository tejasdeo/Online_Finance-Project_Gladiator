package com.example.demo.layer2;


public class TxnNotFoundException extends Exception {
	public TxnNotFoundException(String str) {
		super(str);
	}
	public String getMessage()
	{
		return "Transaction details not found";
	}
}