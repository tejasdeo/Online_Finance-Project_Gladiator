package com.example.demo.layer3;

import com.example.demo.layer2.CardDetail;

public interface Card_detailsRepo {

  CardDetail  getCardLimitByUserId(int user_id);
}
