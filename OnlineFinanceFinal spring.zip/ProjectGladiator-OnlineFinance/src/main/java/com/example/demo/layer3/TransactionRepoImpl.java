package com.example.demo.layer3;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.layer2.Product_details;
import com.example.demo.layer2.Transaction;
import com.example.demo.layer2.UserInformation;
@Repository
public class TransactionRepoImpl extends BaseRepository implements TransactionRepo {

	@Transactional
	public void insertTransaction(Transaction ref) {
		EntityManager entityManager = getEntityManager();
		entityManager.persist(ref);
			System.out.println("transaction inserted..."+ref.getTxnId());

		
	}

	@Transactional
	public Transaction selectTransactionBytxn_id(int txnid) {
		
		EntityManager entityManager=getEntityManager();
		System.out.println("Select transaction repo ");
		return entityManager.find(Transaction.class, txnid);

	}

	@Override
	public List<Transaction> selectTransactionByuser_id(int user_id,int product_id) {
		EntityManager entityManager=getEntityManager();
		Query query = entityManager.createQuery("select t from Transaction t where t.userInformation.userId = :vuser_id and t.productDetail.product_id=:vproduct_id");
		query.setParameter("vuser_id", user_id);
		query.setParameter("vproduct_id", product_id);
		List<Transaction> txnList= query.getResultList();
		return txnList;
	}

	@Override
	public UserInformation selectUserbyId(int user_id) {
		
		EntityManager entityManager=getEntityManager();
		return entityManager.find(UserInformation.class, user_id);
	}
	@Override
	public Product_details selectProductbyId(int product_id) {
		
		EntityManager entityManager=getEntityManager();
		return entityManager.find(Product_details.class, product_id);
	}




	

}
