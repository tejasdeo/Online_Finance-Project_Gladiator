package com.example.demo.layer5;

import java.util.List;

import javax.persistence.NoResultException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.layer2.CardDetail;
import com.example.demo.layer2.Login;
import com.example.demo.layer2.MonthlyTransaction;
import com.example.demo.layer2.Product_details;
import com.example.demo.layer2.Registration;
import com.example.demo.layer2.Transaction;
import com.example.demo.layer2.TxnNotFoundException;
import com.example.demo.layer2.UserInformation;
import com.example.demo.layer2.Users;
import com.example.demo.layer3.DashboardRepositoryImpl;
import com.example.demo.layer3.ProductRepositoryImpl;
import com.example.demo.layer3.RegistrationRepoImpl;
import com.example.demo.layer4.DashboardServiceImpl;
import com.example.demo.layer4.LoginService;
import com.example.demo.layer4.RegistrationService;
import com.example.demo.layer4.TransactionServiceImpl;
import com.example.demo.layer4.User_informationServiceImpl;

@CrossOrigin
@RestController // it is a specialized version of @Component - marker to receive web request
@RequestMapping("/finance")
public class FinanceJPAController {
	@Autowired
	DashboardRepositoryImpl dao;
    
	@Autowired
	RegistrationService regService ;

	@Autowired 
	DashboardServiceImpl dashboardService;

	@Autowired
	LoginService login;

	@Autowired
	User_informationServiceImpl userService;

	@Autowired
	ProductRepositoryImpl productRepo;

	@Autowired
	TransactionServiceImpl txnService;

	@GetMapping
	@ResponseBody
	@RequestMapping(value="/{userId}")
	public List<Transaction> getTransaction(@PathVariable int userId) {

		System.out.println("getTransaction() ");
		//dao.selectTransactionByUserId(userId);
		return dashboardService.selectTransactionByUserId(userId);



	}
	@GetMapping
	@ResponseBody
	@RequestMapping(value="/mtxn/{txnId}")
	public List<MonthlyTransaction> getMonthlyTransaction(@PathVariable int txnId) {
		System.out.println("getMonthlyTransaction() ");
		try {
			return dao.selectMonthlyTransactionByTxnId(txnId);
		} catch (TxnNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null;

	}
	@GetMapping
	@ResponseBody
	@RequestMapping(value="/card/{userId}")
	public CardDetail getCardDetail(@PathVariable int userId) {

		System.out.println("getCardDetail()...method ");
		return dashboardService.selectCardDetailsByUser(userId);

		//		System.out.println("getCardDetail()...method ");
		//		try {
		//			return dao.selectCardDetailByUserId(userId);
		//		} catch (UserNotFoundException e) {
		//			// TODO Auto-generated catch block
		//			e.printStackTrace();
		//		}
		//		
		//		return null;
	}


	@PostMapping(value="/login")
	//@ResponseBody
	//@RequestMapping(value="/login")
	public Users getUserLoginDetails(@RequestBody Login logindto ) throws Exception {
		System.out.println("getUserEmailDetails()...method ");
		try 
		{
			return this.login.login(logindto);
		} catch (NoResultException e) {
			// TODO Auto-generated catch block 
			e.printStackTrace();



		}return null;


	}
	
	@GetMapping 
	@ResponseBody
	@RequestMapping(value = "/getAllUsers")
	public List<UserInformation> getUsers(){
		return userService.selectAllUsersService();
	}
	
	//@ResponseBody
	@GetMapping(value="/deleteUser/{userId}")
	public void deleteUser(@PathVariable int userId) {
		System.out.println("deleteEmployee()...method ");
		userService.deleteUserService(userId);
	}
	
	@GetMapping
	@ResponseBody
	@RequestMapping(value = "/getAllProducts")
	public List<Product_details> getProducts() {
		System.out.println("getProducts() ");
		return productRepo.selectAllProducts();
	}
	
	@PutMapping("/insertTxn/{user_id}/{product_id}")
	public void insertTransaction(@PathVariable int user_id,@PathVariable int product_id,@RequestBody Transaction txn)
	   {
		System.out.println("inserting transaction");
		txnService.insertTransactionService(txn,user_id,product_id);
	   }
	@GetMapping
	@ResponseBody
	@RequestMapping(value = "/getAllTxns/{userId}/{product_id}")
	public List<Transaction> getTransactionbyUserid(@PathVariable int userId,@PathVariable int product_id) 
	   {
		System.out.println("getTransaction() ");
		return txnService.selectTransactionbyUseridService(userId,product_id);

	   }
	@GetMapping
	@ResponseBody
	@RequestMapping(value = "/getProductbyId/{product_id}")
	public Product_details getProductbyId(@PathVariable int product_id) 
	   {
		System.out.println("getTransaction() ");
		return txnService.selectProductbyIdService(product_id);

	   }
	@PostMapping
	@ResponseBody
	@RequestMapping(value="/addUser")
	public String addUserDetails(@RequestBody Registration registration) {
		//registration.setUserInformation();
		return this.regService.insertUser(registration);
		
		
		//return "user added";
		
	}

}
