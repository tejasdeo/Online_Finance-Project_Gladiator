package com.example.demo.layer4;

import java.util.List;

import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.example.demo.layer2.UserInformation;


@Service
public interface User_InformationService {
	List<UserInformation> selectAllUsersService();
	void deleteUserService(int  userId);
}
