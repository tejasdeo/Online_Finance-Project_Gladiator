package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectGladiatorOnlineFinanceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectGladiatorOnlineFinanceApplication.class, args);
	}

}
