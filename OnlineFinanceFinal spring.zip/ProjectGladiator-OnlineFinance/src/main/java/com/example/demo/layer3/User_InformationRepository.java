package com.example.demo.layer3;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.UserInformation;

@Repository
public interface User_InformationRepository {
	List<UserInformation> selectAllUsers();
	void deleteUser(int  userId);
}
