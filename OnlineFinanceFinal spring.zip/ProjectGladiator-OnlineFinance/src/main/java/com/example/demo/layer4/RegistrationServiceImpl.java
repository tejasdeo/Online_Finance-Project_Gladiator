package com.example.demo.layer4;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.layer2.Registration;
import com.example.demo.layer3.RegistrationRepoImpl;

@Service
public class RegistrationServiceImpl implements RegistrationService {
	@Autowired
	RegistrationRepoImpl repo;

	@Transactional
	public String insertUser(Registration register) {
		// TODO Auto-generated method stub
		return repo.addUser(register);
	}

}
