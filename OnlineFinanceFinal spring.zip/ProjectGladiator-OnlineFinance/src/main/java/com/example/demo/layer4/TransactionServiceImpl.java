package com.example.demo.layer4;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.layer2.CardDetail;
import com.example.demo.layer2.Product_details;
import com.example.demo.layer2.Transaction;
import com.example.demo.layer2.TxnNotFoundException;
import com.example.demo.layer2.UserInformation;
import com.example.demo.layer2.UserNotFoundException;
import com.example.demo.layer3.Card_detailsRepoImpl;
import com.example.demo.layer3.TransactionRepoImpl;

@Service
public class TransactionServiceImpl implements TransactionService {
	

	@Autowired
	TransactionRepoImpl txnRepo;
	@Autowired
	Card_detailsRepoImpl crdRepo;
	@Override
	public void insertTransactionService(Transaction txn,int user_id,int product_id) {
		System.out.println("inserting transaction servie..."+user_id);
		//System.out.println("transaction service  "+txn.getProcessing_fee());
		try
		{
		CardDetail card=crdRepo.getCardLimitByUserId(user_id);
		if(card.getCardLimit()>=txn.getPaid())
			txn.setTxnStatus("success");
		else
			txn.setTxnStatus("failure");
		System.out.println("Transaction status "+txn.getTxnStatus());
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
			UserInformation user=txnRepo.selectUserbyId(user_id);
			txn.setUserInformation(user);
			Product_details product=txnRepo.selectProductbyId(product_id);
			txn.setProductDetail(product);
			txnRepo.insertTransaction(txn);
		    System.out.println("update transaction service "+txn.getTxnId()+" "+txn.getUserInformation().getUserId());
			}


	@Override
	public List<Transaction> selectTransactionbyUseridService(int user_id,int product_id) {
		
		return txnRepo.selectTransactionByuser_id(user_id,product_id);
			}


	@Override
	public Product_details selectProductbyIdService(int product_id) {
		// TODO Auto-generated method stub
		return txnRepo.selectProductbyId(product_id);
	}

}
