package com.example.demo.layer3;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.layer2.UserInformation;

@Repository
public class User_InformationRepositoryImpl extends BaseRepository implements User_InformationRepository{

	@Transactional
	public List<UserInformation> selectAllUsers() {
		EntityManager entityManager = getEntityManager();
		Query query = entityManager.createQuery(" from UserInformation");
		List<UserInformation> userList = query.getResultList();
		return userList;
	}

	
//SELECT ba.bookId FROM BookAuthor ba JOIN Book b ON ba.bookId = b.id JOIN BookAuthor ba2 ON b.id = ba2.bookId WHERE ba2.authorId = ? GROUP BY ba.bookId HAVING count(ba.authorId) = 1");
//SELECT ui.userId from User_Infromation ui JOIN AddressDetails ad on ui.userId=ad.userId JOIN

	
	@Transactional
	public void deleteUser(int userId) {
		EntityManager entityManager = getEntityManager();
		UserInformation foundUser = entityManager.find(UserInformation.class, userId);
		
		/*
		 * Query q = entityManager.createNativeQuery("SELECT ba.bookId FROM BookAuthor ba JOIN Book b ON ba.bookId = b.id JOIN BookAuthor ba2 ON b.id = ba2.bookId WHERE ba2.authorId = ? GROUP BY ba.bookId HAVING count(ba.authorId) = 1"); q.setParameter(1, foundUser.getUserId()); 
		 * List<Integer> bookIds =(List<Integer>)q.getResultList();
		 * 
		 * // remove all associations for this author q = entityManager.
		 * createNativeQuery("DELETE FROM BookAuthor ba WHERE ba.authorId = ?");
		 * q.setParameter(1, foundUser.getUserId()); q.executeUpdate();
		 * 
		 * // remove all books that this author wrote alone q =
		 * entityManager.createNativeQuery("DELETE FROM Book b WHERE b.id IN (:ids)");
		 * q.setParameter("ids", bookIds); q.executeUpdate();
		 * 
		 * // remove author entityManager.remove(foundUser);
		 */
		
		if(foundUser != null) {
			entityManager.remove(foundUser);
		}
		else {
			System.out.println("User not found.....");
		}
	}

}


/*
 	public List<Employee> selectAllEmployees() {
		System.out.println("EmployeeRepositoryImpl: Layer 3 ");
		EntityManager entityManager = getEntityManager();
		//EntityTransaction tx = entityManager.getTransaction();
		//tx.begin();
		Query query = entityManager.createQuery(" from Employee");
		List<Employee> empList = query.getResultList();
		System.out.println("emplist "+empList.size());
		for (Employee employee : empList) {
			System.out.println("empname "+employee.getEmployeeName());
			Set<Customer> custs = employee.getCustomers();
			for (Customer cust : custs) {
				System.out.println("customer id    "+cust.getCustomerId());
				System.out.println("customer name  "+cust.getCustomerName());
				System.out.println("customer city  "+cust.getCity());
			}
		}
		//tx.commit();
		return empList;
	}
 
@Transactional
public void deleteEmployee(int empno) throws EmployeeNotFoundException {
	// TODO Auto-generated method stub
	EntityManager entityManager = getEntityManager();
	Employee foundEmp = entityManager.find(Employee.class, empno); //find it 
	if(foundEmp!=null)
		entityManager.remove(foundEmp); // based on PK
	else
		throw new EmployeeNotFoundException("Employee Not Found : "+empno);
	System.out.println("EntityManager: employee removed.. ");

}
*/


// Select u