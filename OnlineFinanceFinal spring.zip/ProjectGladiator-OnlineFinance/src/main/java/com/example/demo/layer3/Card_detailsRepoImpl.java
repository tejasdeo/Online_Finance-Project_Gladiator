package com.example.demo.layer3;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.CardDetail;
import com.example.demo.layer2.Transaction;

@Repository
public class Card_detailsRepoImpl extends BaseRepository implements Card_detailsRepo {

	@Transactional
	public CardDetail getCardLimitByUserId(int user_id) {
		
		EntityManager entityManager=getEntityManager();
		Query query = entityManager.createQuery("select c from CardDetail c where c.userInformation.userId = :vuser_id");
		query.setParameter("vuser_id", user_id);
		CardDetail card=(CardDetail) query.getSingleResult();
		return card;
	}

}
