package com.example.demo.layer4;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.layer2.UserInformation;
import com.example.demo.layer3.User_InformationRepositoryImpl;


@Service
public class User_informationServiceImpl implements User_InformationService {

	@Autowired
	User_InformationRepositoryImpl userRepo;

	public List<UserInformation> selectAllUsersService() {
		return userRepo.selectAllUsers();
	}

	@Override
	public void deleteUserService(int userId) {
		System.out.println("deleteEmployeeService()...method ");
		String message="Employee Not Found";

		boolean deleted=false;
		userRepo.deleteUser(userId);//invoke the repo
		deleted= true;
		message = "User Deleted";
		System.out.println("SErvice deleted :" );

	}

}


/*
	@Autowired
	EmployeeRepositoryImpl empRepo;

	public List<Employee> selectAllEmployeesService() {
		//business logic goes here if desired...
		System.out.println("EmployeeServiceImpl: Layer 4 ");
		//then talk to the kitchen code written below
		return empRepo.selectAllEmployees();
	}
 */