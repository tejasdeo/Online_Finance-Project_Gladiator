package com.example.demo.layer3;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;
import com.example.demo.layer2.Product_details;

@Repository
public class ProductRepositoryImpl extends BaseRepository implements ProductRepository {

	@Transactional
	public List<Product_details> selectAllProducts() {
		
		EntityManager entityManager = getEntityManager();
		System.out.println("inside impl");
		Query query = entityManager.createQuery(" from Product_details");
		List<Product_details> productList= query.getResultList();
		System.out.println("productList "+productList.size());
		for (Product_details details : productList) {
			System.out.println("productImage "+details.getImageurl());
		}
		
		System.out.println("inside impl 11111111111111111111");
		return productList;
	}

	
}
