package com.example.demo;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.Date;
import java.util.List;

import com.example.demo.layer2.AddressDetails;
import com.example.demo.layer2.BankDetails;
import com.example.demo.layer2.CardDetail;
import com.example.demo.layer2.CardNotFoundException;
import com.example.demo.layer2.MonthlyTransaction;
import com.example.demo.layer2.Product_details;
import com.example.demo.layer2.Transaction;
import com.example.demo.layer2.TxnNotFoundException;
import com.example.demo.layer2.UserInformation;
import com.example.demo.layer3.BaseRepository;
import com.example.demo.layer3.BaseRepositoryImpl;
import com.example.demo.layer3.Card_detailsRepoImpl;
import com.example.demo.layer3.DashboardRepositoryImpl;
import com.example.demo.layer3.LoginRepoImpl;
import com.example.demo.layer3.ProductRepositoryImpl;
import com.example.demo.layer3.TransactionRepoImpl;
import com.example.demo.layer3.User_InformationRepository;
import com.example.demo.layer3.User_InformationRepositoryImpl;
import com.example.demo.layer2.UserNotFoundException;
import com.example.demo.layer2.Users;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
@SpringBootTest
class FinanceTest {

	@Autowired
	User_InformationRepositoryImpl userDao;

	@Autowired
    DashboardRepositoryImpl dashboardDao;
   
    @Autowired
    LoginRepoImpl loginDao;
    
    @Autowired
    ProductRepositoryImpl productDao;
    
    @Autowired
    TransactionRepoImpl txnDao;
    
	@Autowired
    Card_detailsRepoImpl cardDao;
	
	@Autowired 
	BaseRepositoryImpl base;
   
   @Test
	public void deleteUserInformation() throws Exception {
	//ArrayList<Department> allDepts = dao.selectAllDepartments();
	UserInformation user = new UserInformation();
	try {
	   userDao.deleteUser(9824);
	} 
	/*catch (UserNotFoundException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
	//}
	}*/
	catch (Exception e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
    }

	}


	@Test
	public void showAllUsersTest() {
	List<UserInformation> user = userDao.selectAllUsers();
	for (UserInformation u : user ) 
	{
	System.out.println("user_id :" + u.getUserId());
	System.out.println("Phone No: " + u.getPhoneNo());
	System.out.println("Email Id : " + u.getEmailId());
	//System.out.println(" :"+ ());
	//System.out.println(" :"+());
	}
   }
	
    @Test
    public void findTxnByUserIdTest() {
        //System.out.println("Transaction Repo : "+ dao);
       
        try {
            List<Transaction> txn = dashboardDao.selectTransactionByUserId(9821);
            for (Transaction t : txn) {
                System.out.println("Txn id : "+ t.getTxnId());
                System.out.println("Amount Paid : "+ t.getPaid());
                System.out.println("Name : "+ t.getUserInformation().getName());
                System.out.println("---------------------------");
               
            }
           
        }
        catch(UserNotFoundException e) {
            System.out.println("user not found "+e.getMessage());
        }
    }
   
    @Test
    public void findMTxnByTxnIdTest() {
        try {
            List<MonthlyTransaction> mtxn= dashboardDao.selectMonthlyTransactionByTxnId(20204);
            for(MonthlyTransaction m : mtxn) {
                System.out.println("MTxn id : "+ m.getMtxnId());
                System.out.println("Amount Paid : "+ m.getMonthlyInstallment());
                //System.out.println("MTxn Date :" m.getMtxnDate());
                System.out.println("---------------------------");
               
            }
           
               
           
        } catch (TxnNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
   
    @Test
    public void findCardDetailsByUserTest() throws UserNotFoundException {
        try {
            CardDetail card = dashboardDao.selectCardDetailByUserId(9823);
            System.out.println("Card Number : "+card.getCardNumber());
            System.out.println("Card Type  : "+card.getCardType());
            System.out.println("Card Limit : " + card.getCardLimit());
            System.out.println("Card validity :  "+ card.getValidity());
           
        } catch (UserNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
   
   /* @Test
    public void findUserByEmail() {
        UserInformation user = dashboardDao.selectUserByEmail("steve@starkindustries.com");
        System.out.println("User name : "+ user.getName());
    }
*/   
    @Test
    public void selectUserByIdAndPass() {
        Users user;
        try {
            user = loginDao.selectUserByUserNameAndPass(4575,"JANE@4575");
            System.out.println("NAME : "+ user.getUserInformation().getName());
        } catch (UserNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
       
    }
@Test
	
	public void showAllProductsTest() {
		List<Product_details> products = productDao.selectAllProducts();
		for (Product_details pd : products) {
			System.out.println("txnid : " + pd.getProduct_id());
			System.out.println("EMI period : " + pd.getProduct_name());
			System.out.println("ProcessingFee : " + pd.getProduct_type());
			System.out.println("transaction status "+pd.getCost());
			
		}
	}

@Test
public void insertTransactionTest() {
	Transaction txn = new Transaction();
	UserInformation usn=new UserInformation();
	txn.setPaid(10000);
	txn.setTxnDate(Date.valueOf("2021-09-01"));
	txn.setTxnStatus("success");
	txn.setEmiPeriod("12 months");
	txn.setProcessingFee(10);
	/*usn.setName("julia");
	usn.setPhoneNo("9010243580");
	usn.setEmailId("julia@gmail.com");
	usn.setUserJoiningDate(Date.valueOf("2019-09-01"));
	txn.setUserInformation(usn);*/
    txnDao.insertTransaction(txn);
}

@Test
public void showTransactionByidTest()
{
	Transaction txn=txnDao.selectTransactionBytxn_id(20213);
    System.out.println("Emi period "+txn.getEmiPeriod());
    System.out.println("Transaction status :"+txn.getTxnStatus());
}

@Test
public void selectProductById()
{
	Product_details product=txnDao.selectProductbyId(20047);
	System.out.println("Product name "+product.getProduct_name());
	System.out.println("Product type "+product.getProduct_type());
	System.out.println("Product cost "+product.getCost());
}

@Test
public void addUser() {
    
    UserInformation userInformation = new UserInformation();
    userInformation.setName("Kevin");
    userInformation.setEmailId("abc@gmail.com");
    userInformation.setPhoneNo("9849584");
    userInformation.setUserJoiningDate(Date.valueOf("2020-09-09"));
 
    BankDetails bankDetails = new BankDetails();
    bankDetails.setAccId(5596);
    bankDetails.setBank("HDFC");
    bankDetails.setIfscCode("KKBK003");
    bankDetails.setUserInformation(userInformation);
   
    CardDetail cardDetail = new CardDetail();
    cardDetail.setCardNumber(45844);
    cardDetail.setCardIssueDate(Date.valueOf("2020-09-03"));
    cardDetail.setCardLimit(2000);
    cardDetail.setCardType("Platinum");
    cardDetail.setJoiningFee(2000);
    cardDetail.setStatus("Active");
    cardDetail.setValidity(Date.valueOf("2022-08-04"));
    cardDetail.setUserInformation(userInformation);
   
    AddressDetails addressDetails = new AddressDetails();
    addressDetails.setAddress("wall");
    addressDetails.setCity("Pune");
    addressDetails.setState("Karnataka");
    addressDetails.setPincode("48586");
    addressDetails.setUserInformation(userInformation);
   
    Users users = new Users();
    users.setUserName(4890);
    users.setPassword("NICK@4890");
    users.setUserStatus("Active");
    users.setUserType("NON ADMIN");
    users.setUserInformation(userInformation);
   
    userInformation.setAddressDetails(addressDetails);
    userInformation.setBankDetails(bankDetails);
    userInformation.setCardDetail(cardDetail);
    userInformation.setUsers(users);
    base.saveRecord(userInformation);
   
   
   
}


}
