export class Product_details
{
   product_id:number;
   product_type:string;
   product_name:string;
   cost:number;
   imageurl:string;
}

