export class User_Information{
  userId: number;
  name: string;
  phoneNo: string;
  emailId: string;
  userJoiningDate: Date;
}
