export class Registration

{
    emailId:string;
    name:string;
	phoneNo:string;
	userJoiningDate:Date=new Date();
	accId:number;
	bank:string;
	ifscCode:string;
    address:string;
    state:string;
	city:string;
    pincode:string;
	userName:number;
	cardType:string;
	password:string;

	
}