export class UserInformation{
    name:string="Priya";
    phone_no:string="9020456981";
    email_id:string="saranya@gmail,com";
    user_join:Date=new Date();
}